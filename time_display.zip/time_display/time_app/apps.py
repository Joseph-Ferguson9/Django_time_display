from django.apps import AppConfig


class TheTimeConfig(AppConfig):
    name = 'the_time'
